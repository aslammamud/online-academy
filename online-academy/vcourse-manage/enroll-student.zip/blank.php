<?php include('header.php') ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                 
				 
				 <div class="col-12">
                        <div class="card">
                 <div class="card-body">
                 <div class="content">
            <div class="container-fluid">
                <div class="row">
				sasa
				 </div>
             </div>
             </div>
             </div>
             </div>
				 
				 </div>
             </div>
        </div>

<?php include('footer.php') ?>