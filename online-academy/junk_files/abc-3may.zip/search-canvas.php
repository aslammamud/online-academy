<style>
    @media only screen and (max-width: 575.98px){
        .banner-wrapper h1{
            font-size: 46px !important;
            padding-top: 10px !important;
        }
        
    }
    
</style>

<section class="section section-search">
					<div class="container">
					<div class="row">
					<div class="col-sm-6">
						<div class="banner-wrapper m-auto text-center">
							<div>
								<h1 class="text-left text-white myfont" style="font-size:62px;">কথায় নয়, আমরা কাজে বিশ্বাসী। তাই সফলতা নিশ্চিত করাই আমাদের লক্ষ্য </h1>
							
							</div>
				
						</div>
						</div>
	
					<div class="col-sm-6">
						</div>
						</div>
					</div>
</section>