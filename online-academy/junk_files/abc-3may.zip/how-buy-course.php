
<?php include'header.php'; ?>

<div style="background-color: green; height: 10px;"></div>
<section id="title">
	<center><div><h3>কিভাবে কোর্স কিনবেন ?</h3></div></center>
</section>
<style type="text/css">
	#title div{
		width: 100%;
		height: 80px;
		padding: 30px;
		background-color: #a4d68e;

	}
</style>



<section id="course-buy" style="margin-bottom: 50px; margin-top: 30px;">
  <center><div class="cbuy">
    <h3 style="margin-top: 50px; margin-bottom: 50px;">ভিডিও দেখুন কিভাবে কোর্সটি কিনবেন</h3>
    

</div>

</center>




</div>



  
</section>





<section id="how-instructor" style="margin-bottom: 100px;">
  <div class="h-instructor">
    <h3 style="margin-top: 50px;"></h3>

    
    <div id="content" > 


       <section class="padding-top-60 padding-bottom-60">
      <div class="container "> 
        <div class="row"> 
        <link rel="stylesheet" href="style.css">

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
    
        </button>
      </h5>
    </div>
    <div >
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  
  <center><iframe width="650" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY">
</iframe></center>
  </div>


<div class="buy-info">
  <p style="width: 90%;margin-top: 50px; ">Looking for a unique, exciting, gift idea that the recipient will actually use and benefit from? Consider the gift of online learning through Udemy, an online learning platform that offers a wide variety of courses for just about anyone wanting to learn. This gift is one that truly keeps on giving, as it allows the recipient a way to better themselves through mastery of new knowledge or a new skill.Looking for a unique, exciting, gift idea that the recipient will actually use and benefit from? Consider the gift of online learning through Udemy, an online learning platform that offers a wide variety of courses for just about anyone wanting to learn. This gift is one that truly keeps on giving, as it allows the recipient a way to better themselves through mastery of new knowledge or a new.
 
</p>


      </div>
    </div>
  </div>
  
</div>

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         
        </button>
      </h5>
    </div>
    <div>
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <div class="buy-c" style="margin-left: 30px; margin-bottom: 100px; margin-top: 30px;">
  
<h3>How to Buy Udemy Course</h3>

<ol style="margin-top: 20px;">
  <li>1. Identify a Good Udemy Course Gift Recipient</li>
  <li>2. Identify the Course You’d Like to Gift</li>
  <li>3. Purchase Your Gift</li>
  <li>4. Follow Up With Your Recipient</li>

</ol>

      </div>
    </div>
  </div>
  
</div>


<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         
        </button>
      </h5>
    </div>
    <div >
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <p style="margin-top: 30px;  ">Giving an online course from Udemy is quick and easy. You can access Udemy’s brief instructions on how to give (and receive) a Udemy course here. To provide a more comprehensive guide, I’ve compiled four steps loaded with all the necessary information to guide you through the process of giving this innovative gift.
</p>
<p style="margin-top: 30px; ">Giving an online course from Udemy is quick and easy. You can access Udemy’s brief instructions on how to give (and receive) a Udemy course here. To provide a more comprehensive guide, I’ve compiled four steps loaded with all the necessary information to guide you through the process of giving this innovative gift.
</p>
<p style="margin-top: 30px; ">Giving an online course from Udemy is quick and easy. You can access Udemy’s brief instructions on how to give (and receive) a Udemy course here. To provide a more comprehensive guide, I’ve compiled four steps loaded with all the necessary information to guide you through the process of giving this innovative gift.
</p>
      </div>
    </div>
  </div>
  
</div>


</div>
</div>
</div>







  

 

  </div>
</section>



<?php include'footer.php'; ?>