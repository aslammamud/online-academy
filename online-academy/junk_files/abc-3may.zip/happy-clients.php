<section class="section">
<div class="container">
   <div class="row vc_custom_1536822373411">
			<div class="col-6 col-sm-2">
               <div class="stm_lms_courses_category" style="background-color: #eab830">
                  <a href="#" title="Analysis of Algorithms" class="no_deco" data-wpel-link="internal" rel="nofollow">
                     <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                     <h4 class="myfont fs36" style="line-height:26px;">প্রশ্ন উত্তর </h4>
                     <h4 class="myfont fs36">৭৫০</h4>
                  </a>
               </div>
			   </div>
			   <div class="col-6 col-sm-2">
               <div class="stm_lms_courses_category" style="background-color: #307ad5">
                  <a href="#" title="Economics &amp; Finance" class="no_deco" data-wpel-link="internal" rel="nofollow">
                     <i class="fa fa-users" aria-hidden="true"></i>
                     <h4 class="myfont fs36" style="line-height:26px;">স্টুডেন্ট</h4>
                     <h4 class="myfont fs36">২৩৫০</h4>
                  </a>
               </div>
               </div>
			   <div class="col-6 col-sm-2">
               <div class="stm_lms_courses_category" style="background-color: #307ad5">
                  <a href="#" title="Economics &amp; Finance" class="no_deco" data-wpel-link="internal" rel="nofollow">
                     <i class="fa fa-user-o" aria-hidden="true"></i>
                      <h4 class="myfont fs36" style="line-height:26px;">শিক্ষক </h4>
                     <h4 class="myfont fs36">২৩৩</h4>
                  </a>
               </div>
               </div>
			   <div class="col-6 col-sm-2">
               <div class="stm_lms_courses_category" style="background-color: #1ec1d9">
                  <a href="#" title="Environmental Sciences" class="no_deco" data-wpel-link="internal" rel="nofollow">
                     <i class="fa fa-book" aria-hidden="true"></i>
                     <h4 class="myfont fs36" style="line-height:26px;">ফ্রি কোর্স </h4>
                     <h4 class="myfont fs36">২১</h4>
                  </a>
               </div>
               </div>
			   
			   <div class="col-6 col-sm-2">
			                  <div class="stm_lms_courses_category" style="background-color: #10c45c">
                  <a href="#" title="Graphic &amp; Web-design" class="no_deco" data-wpel-link="internal" rel="nofollow">
                    <i class="fa fa-heart" aria-hidden="true"></i>
                     <h4 class="myfont fs36" style="line-height:26px;">রিভিউ</h4>
                     <h4 class="myfont fs36">১১৫০</h4>
                  </a>
               </div>
			   </div>
			   
			   <div class="col-6 col-sm-2">
			                  <div class="stm_lms_courses_category" style="background-color: #d94da6">
                  <a href="#" title="Software Training" class="no_deco" data-wpel-link="internal" rel="nofollow">
                     <i class="fa fa-handshake-o" aria-hidden="true"></i>
                      <h4 class="myfont fs36" style="line-height:26px;">টিউটোরিয়াল  </h4>
                     <h4 class="myfont fs36">১০৫</h4>
                  </a>
               </div>
			   </div>
            
   </div>
</div>
</section>
