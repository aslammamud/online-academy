<?php include'header.php'; ?>

<div style="background-color: green; height: 10px;"></div>
<section id="title">
	<center><div><h3>প্রিমিয়াম ব্লগ</h3></div></center>
</section>



<section>
	<center><h3 style="margin-bottom: 50px; margin-top: 50px;">ডাউনলোড করতে এখানে ক্লিক করুন</h3>
	<img src="./images/google.png"></center>
</section>

<style type="text/css">
	#title div{
		width: 100%;
		height: 80px;
		padding: 30px;
		background-color: #a4d68e;

	}
</style>

<?php include'footer.php'; ?>