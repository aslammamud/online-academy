<?php 
	include 'header.php';

	$course_id = $_GET['id'];

	$sql_courses = "SELECT * FROM courses WHERE course_id = $course_id";
	mysqli_query($con,'SET CHARACTER SET utf8');
	$result_courses = mysqli_query($con, $sql_courses);
	$course = mysqli_fetch_assoc($result_courses);
?>

<style>
  .vhasha {
   top: 22%;
    z-index: 3;
    position: absolute;
    left:65% ;
  }
  .icon:hover {
    color: #ff0000;
}
</style>
<section class="bg-dark">
  <div class="container">

    <div class="col-12 col-sm-12">
      <div class="row">
        <div class="col-sm-8">
          <h2 class="text-white px-3 myfont fs36 mt-5"> <strong><?php echo $course['course_title']; ?></strong></h2>
          <h4 class="text-white px-3 mt-3"><?php echo $course['course_short_description']; ?></h4>
          <div class="row mb-5">
            <div class="col-12 col-sm-7 px-4">
              <span class="fa fa-star filled" style="color: yellow;"></span>
              <span class="fa fa-star filled" style="color: yellow;"></span>
              <span class="fa fa-star filled" style="color: yellow;"></span>
              <span class="fa fa-star filled" style="color: yellow;"></span>
              <span class="fa fa-star filled" style="color: yellow;"></span>
              <span class="text-white px-3">  (12,092 ratings)  85,397students</span>
              <P class="text-white px-3 mt-2"> Created By
                <a class="text-info mt-2" href=""> Aslam Mamud</a></P>
                <div class="row">
              
              <div class="col-md-3">
                <button type="button" class="btn btn-dark border-info">Wishlist <i class="fa fa-heart-o" aria-hidden="true"> </i></button>
              </div>
              <div class="col-md-3">
               <button type="button" class="btn btn-dark border-info">Share <i class="fa fa-share-square-o" aria-hidden="true"></i></button>
              </div>
              <div class="col-md-5">
                <button type="button" class="btn btn-dark border-info">Gift this course <i class="fa fa-gift" aria-hidden="true"></i></button>
              </div>
            </div>
                
              </div>
            </div>
          </div>
    
        </div>
        
      </div>
    </div>
  </section>
        <div class="col-sm-4 vhasha">
            <div  class="card shadow bg-white rounded p-3 mb-5">
              <div class="card border-white mb-3 " >
                <div class="embed-responsive embed-responsive-16by9">
                  <iframe width="560" height="315" src="https://www.youtube.com/embed/awLdVfPAGG4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                
                <div class="card-body text-primary">
                  <h2 class="card-title"><strong> ৳<?php echo $course['course_discount_price']; ?></strong></h2>
				  <?php
					$course_price = (int)$course['course_price']; 
					$differene = (int)$course['course_price'] - (int)$course['course_discount_price']; 
					$disc_percent = $differene/($course_price/100);
				  ?>
                  <h6><del>৳<?php echo $course['course_price']; ?></del> <?php echo (int)$disc_percent; ?>% off</h6>
                  <h6 class="text-danger">5 hours left at this price!</h6>
                  <button type="button" class="btn btn-danger mt-2 myfont fs36" style="width: 100%; background:green; border:none;"><strong>  কোর্সটি কিনুন  </strong></button>
                  <button type="button" class="btn btn-white border-info text-info mt-2" style="width: 100%"><strong> কার্টে রাখুন </strong></button>
                  <p class="mentor-payment text-dark mt-3 text-center">30-Day Money-Back Guarantee </p>
                  <div class="custom-file">
                    <input type="text" class="custom-file-input" id="validatedCustomFile">
                    <label class="custom-file-label" for="validatedCustomFile">Enter coupon</label>
                  </div>
                  <hr>
                  <h4 class="card-title"><strong>Training 5 or more people?</strong></h4>
                  <h6>Get your team access to 5,500+ top Udemy courses anytime, anywhere.</h6>
                  <button type="button" class="btn btn-white border-info text-info mt-2" style="width: 100%"><strong> Try ABC Academy </strong></button>
                </div>
              </div>
            </div>
          </div>
  <div class="container">
    <div class="row">
	
	
	</div>
      <div class="col-12 col-md-12">
        <div class="row mb-5">
          <div class="col-md-8">
            <div class="header">
              <h3 class="mt-5 myfont fs36"><strong> এই কোর্সে যা যা অন্তর্ভুক্ত থাকবে ?  </strong></h3>
              
            </div>
            <div class="row">
              
              <div class="col-md-6">
                <ul class="col-12 px-4">
                  <li class=" text-dark h5">  23.5 hours on-demand video </li>
                  <li class=" text-dark h5">  Full lifetime access </li>
                  <li class=" text-dark h5">  Certificate of completion </li>
                </ul>
              </div>
              <div class="col-md-6">
                <ul class="col-12 ">
                  <li class=" text-dark h5">  17 downloadable resources </li>
                  <li class=" text-dark h5">  Access on mobile and TV </li>
                  
                </ul>
              </div>
            </div>
            <div class="row">
              <div class="col-md-11 mt-5">
                <div class="card shadow">
                  <div class="card-header bg-light">
                    <h3 class="myfont fs36"> <strong> এই কোর্সটি কাদের জন্য ?  </strong></h3>
                  </div>
                  <div class="card-body bg-light">
                    
                    <div class="row">
                      
                      <div class="col-md-6">
                        <ul class="col-12 px-4">
                          <li class=" text-dark h6"> A clear understanding of the principles and benefits of good UX and how to apply it to your website </li>
                          <li class=" text-dark h6 mt-4"> The confidence to know what information should be included in your website, and how to design it to increase conversions </li>
                          
                        </ul>
                      </div>
                      <div class="col-md-6">
                        <ul class="col-12 ">
                          <li class=" text-dark h6">  A strategy for making sure you know what people need from your website, and what you or your client needs from it in order to succeed </li>
                          <li class=" text-dark h6 mt-4">  The ability to code a variety of websites with HTML, CSS, WordPress, and other tools </li>
                          
                        </ul>
                      </div>
                    </div>


                  </div>
                </div>
              </div>
              
            </div>

			<div class="row">
              <div class="col-md-11 mt-5">
                <div class="card shadow">
                  <div class="card-header bg-light">
                    <h3 class="myfont fs36"> <strong> কোর্স কন্টেন্ট  </strong></h3>
                  </div>
                  <div class="card-body bg-light">
                    
                    <div class="row">
                 Test
				   </div>


                  </div>
                </div>
              </div>
              
            </div>

        </div>
      </div>
      
    </div>
  </div>
  <?php include 'footer.php'; ?>