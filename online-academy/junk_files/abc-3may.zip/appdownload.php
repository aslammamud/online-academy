<section class="section mt-5  bg-dark">
<br>
<br>
<br>
<div class="container">
    <div class="row">
      <div class="col-md-5 col-sm-6"> 
        <!--app image Start-->
        <div class="appimg"><img src="images/mobile.png" alt="Your alt text here"></div>
        <!--app image end--> 
      </div>
	  <div class="col-md-7 col-sm-6 text-white"> 
        <!--app info Start-->
        <h1 class="pt-5 pb-2 text-white myfont">ফ্রি কোর্স করতে অ্যাপটি ইনস্টল করুন</h1>
        <p class="abc_normal_text" style="font-size:16px;">এবিসি একাডেমি বাংলাদেশের একমাত্র অনলাইন লাইভ লার্নিং এবং ভিডিও কোর্স সেলিং ফ্লাটফর্ম।  আমাদের উদ্দেশ্য   বাংলাদেশের মানুষের প্রয়োজনীয় দক্ষতা অর্জনের সহায়তা করা।  নিজে শিখবো অপরকে শিখাবো এই স্লোগান এর মাধ্যমে আমাদের যাত্রা শুরু হয় ।  ডিজিটাল প্রযুক্তি ব্যবহার করে বাংলাদেশকে ডিজিটাল বাংলাদেশ গড়ার লক্ষে নিয়োজিত একটি প্রতিষ্ঠান । </p>
        <div class="pt-2">
          <div class="row">
            <div class="col-md-5 col-sm-6 col-xs-6 text-center mb-2"><a href="#"><img src="images/andriod.png" alt=""></a></div>
            <div class="col-md-5 col-sm-6 col-xs-6 text-center mb-4"><a href="#"><img src="images/apple.png" alt=""></a></div>
          </div>
        </div>
        <!--app info end--> 
      </div>
    </div>
</div>
</section>