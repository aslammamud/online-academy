<?php include'header.php'; ?>

<div style="background-color: green; height: 10px;"></div>
<section id="title">
	<center><div><h3>কিভাবে ইন্সট্রাক্টর হবেন ?</h3></div></center>
</section>
<style type="text/css">
	#title div{
		width: 100%;
		height: 80px;
		padding: 30px;
		background-color: #a4d68e;

	}
</style>



<section id="how-instructor" style="margin-bottom: 100px;">
	<div class="h-instructor">
		<h3 style="margin-top: 50px;"></h3>

		
		<div id="content" > 


       <section class="padding-top-60 padding-bottom-60">
      <div class="container "> 
        <div class="row"> 
        <link rel="stylesheet" href="style.css">

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         Step 1
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  
  <p  style="margin-bottom: 50px; margin-left: 30px;">Apni jekono akti payment method select korun

Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” butto
</p>

      </div>
    </div>
  </div>
  
</div>

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         Step 2
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <p  style="margin-bottom: 50px;margin-left: 30px;">
Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” 

</p>
      </div>
    </div>
  </div>
  
</div>


<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         Step 3
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <p  style="margin-bottom: 50px;margin-left: 30px;">Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the </p>
      </div>
    </div>
  </div>
  
</div>

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         Step 4
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <p  style="margin-bottom: 50px;margin-left: 30px;">Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout”<br><br><center><img src="./images/done.png"></center></p>
      </div>
    </div>
  </div>
  
</div>

</div>
</div>
</div>







  

 

	</div>
</section>

<style type="text/css">
	#how-instructor .h-instructor table tr,td{
		
		/*border: 1px solid #000;*/

		border: none;

	}
</style>


<?php include'footer.php'; ?>
