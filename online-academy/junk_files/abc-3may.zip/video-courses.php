
<?php include 'header.php'; ?>

<link rel="stylesheet" href="footer-style.css">


    <div class="content mt-2">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-lg-4 col-xl-3">


                    <div style="position: sticky; top: 20px;">
                        <div class="card search-filter">
                            <div class="card-header">
                                <h4 class="card-title mb-0">Search videos</h4>
                            </div>
                            <div class="card-body">
                                <div class="filter-widget">
                                    <div class=" mb-3"><input type="text" class="form-control datetimepicker" placeholder="Seach"></div>
                                </div>
                               
                                <div class="filter-widget ">
                                    <h4>Select Your Course Type</h4>
                                   <div class="form-check mb-3">
                                          <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                          <label class="form-check-label" for="flexCheckDefault">
                                            Digital Marketer
                                          </label>
                                        </div>
                                    
                                        <div class="form-check mb-3">
                                          <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                          <label class="form-check-label" for="flexCheckDefault">
                                           UNIX, Calculus, Trigonometry
                                          </label>
                                        </div>
                                      <div class="form-check mb-3">
                                          <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                          <label class="form-check-label" for="flexCheckDefault">
                                          Computer Programing
                                          </label>
                                        </div>
                                      <div class="form-check mb-3">
                                          <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                          <label class="form-check-label" for="flexCheckDefault">
                                           ASP, .NET Computer Gaming
                                          </label>
                                        </div>
                                     <div class="form-check mb-3">
                                          <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                          <label class="form-check-label" for="flexCheckDefault">
                                           HTML CSS
                                          </label>
                                        </div>
                                      <div class="form-check mb-3">
                                          <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                          <label class="form-check-label" for="flexCheckDefault">
                                          VB VB.NET
                                          </label>
                                        </div>
                                </div>
                                <div class="btn-search">
                                    <button type="button" class="btn btn-block btn-primary">Search videos</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                


                <!-- <div class="col-md-12 col-lg-8 col-sm-12 col-xl-9">
                    <div class="row row-cols-1 row-cols-md-3">
                        <div class="col">
                            <div class="card custom-card">
                              <img src="images/course-x.jpg">
                              <br>


                                 
                              <div class="middle custom-read-more">
                                <a href="#" class="text">Read more </a>
                              </div>

                              <img src="images/img11.jpg" class="rounded-circle m-auto " height="120x" width="120px" alt="...">

                              <div class="card-body">
                                  <h5 class="card-title m-auto">Ovi Sheikh</h5>
                                  <p class="mentor-type"> Management </p>
                                  <p class="mentor-location"> <i class="fa fa-map-marker" aria-hidden="true"> Dhaka Bangladesh </i> </p>
                                  <span class="fa fa-star checked"></span>
                                  <span class="fa fa-star checked"></span>
                                  <span class="fa fa-star checked"></span>
                                  <span class="fa fa-star"></span>
                                  <span class="fa fa-star"></span>
                                  <p class="mentor-text"><i class="fa fa-comments-o" aria-hidden="true"> Feedback </i> </p>
                                  <p class="mentor-payment"><i class="fa fa-money" aria-hidden="true"> ৳2000 - ৳10000 </i> </p>
                              </div>
                                <button type="button" class="btn btn-success">Book Now</button>
                            </div>
                        </div>                          

                        <div class="col mb-4">
                            <div class="card">
                                <br>
                                <img src="images/img11.jpg" class="rounded-circle m-auto " height="120x" width="120px" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title m-auto">Ovi Sheikh</h5>
                                    <p class="mentor-type"> Management </p>
                                    <p class="mentor-location"> 
                                    <i class="fa fa-map-marker" aria-hidden="true"> Dhaka Bangladesh </i> </p>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <p class="mentor-text"><i class="fa fa-comments-o" aria-hidden="true"> Feedback </i> </p>
                                    <p class="mentor-payment"><i class="fa fa-money" aria-hidden="true"> ৳2000 - ৳10000 </i> </p>
                                </div>
                                <button type="button" class="btn btn-success">Book Now</button>
                            </div>
                        </div> -->



                        <!-- <div class="col mb-4">
                            <div class="card">
                                <br>
                                <img src="images/img11.jpg" class="rounded-circle m-auto " height="120x" width="120px" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title m-auto">Ovi Sheikh</h5>
                                    <p class="mentor-type"> Management </p>
                                    <p class="mentor-location"> <i class="fa fa-map-marker" aria-hidden="true"> Dhaka Bangladesh </i> </p>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <p class="mentor-text"><i class="fa fa-comments-o" aria-hidden="true"> Feedback </i> </p>
                                    <p class="mentor-payment"><i class="fa fa-money" aria-hidden="true"> ৳2000 - ৳10000 </i> </p>
                                </div>
                                <button type="button" class="btn btn-success">Book Now</button>
                            </div>
                        </div>
                    </div>



                    <div class="row row-cols-1 row-cols-md-3">
                        <div class="col mb-4">
                            <div class="card">
                                <br>
                                <img src="images/img11.jpg" class="rounded-circle m-auto " height="120x" width="120px" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title m-auto">Ovi Sheikh</h5>
                                    <p class="mentor-type"> Management </p>
                                    <p class="mentor-location"> <i class="fa fa-map-marker" aria-hidden="true"> Dhaka Bangladesh </i> </p>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <p class="mentor-text"><i class="fa fa-comments-o" aria-hidden="true"> Feedback </i> </p>
                                    <p class="mentor-payment"><i class="fa fa-money" aria-hidden="true"> ৳2000 - ৳10000 </i> </p>
                                </div>
                                <button type="button" class="btn btn-success">Book Now</button>
                            </div>
                        </div>

                        <div class="col mb-4">
                            <div class="card">
                                <br>
                                <img src="images/img11.jpg" class="rounded-circle m-auto " height="120x" width="120px" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title m-auto">Ovi Sheikh</h5>
                                    <p class="mentor-type"> Management </p>
                                    <p class="mentor-location"> <i class="fa fa-map-marker" aria-hidden="true"> Dhaka Bangladesh </i> </p>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <p class="mentor-text"><i class="fa fa-comments-o" aria-hidden="true"> Feedback </i> </p>
                                    <p class="mentor-payment"><i class="fa fa-money" aria-hidden="true"> ৳2000 - ৳10000 </i> </p>
                                </div>
                                <button type="button" class="btn btn-success">Book Now</button>
                            </div>
                        </div>



                        <div class="col mb-4">
                            <div class="card">
                                <br>
                                <img src="images/img11.jpg" class="rounded-circle m-auto " height="120x" width="120px" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title m-auto">Ovi Sheikh</h5>
                                    <p class="mentor-type"> Management </p>
                                    <p class="mentor-location"> <i class="fa fa-map-marker" aria-hidden="true"> Dhaka Bangladesh </i> </p>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                    <p class="mentor-text"><i class="fa fa-comments-o" aria-hidden="true"> Feedback </i> </p>
                                    <p class="mentor-payment"><i class="fa fa-money" aria-hidden="true"> ৳2000 - ৳10000 </i> </p>
                                </div>
                                <button type="button" class="btn btn-success">Book Now</button>
                            </div>
                        </div>
                    </div> -->
                    
                </div>
            </div>
        </div>
    </div>


    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

 

<?php include 'footer.php'; ?>