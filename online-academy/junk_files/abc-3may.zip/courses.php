<?php include 'header.php'; ?>
<div class="h2 bred_cus myfont fs42">আমাদের একাডেমির ভিডিও কোর্স গুলো </div>
<div class="container-fluid">
   <div class="row my-4">
      <div class="col-md-12">
         <div class="row">
		 
		 <?php 
		    $sql_courses = "SELECT * FROM courses";
			mysqli_query($con,'SET CHARACTER SET utf8');
			$result_courses = mysqli_query($con, $sql_courses);
			$count_course = mysqli_num_rows($result_courses);
			
			if($count_course>0){
				foreach($result_courses as $course){
					 
		 ?>
            <div class="col-md-3">
               <div class="card bg-light">
                  <img class="card-img-top" src="<?php echo $course['course_image']; ?>" alt="img" height="150px" width="240px">
                  <div class="custom-card card-body">
                     <div class="course-details mt-2">
                        <a href="course-details.php">
                           <h5 class="title myfont fs26"><a href="course-details.php?id=<?php echo $course['course_id'] ?>" class="tittle"><?php echo $course['course_title']; ?></a></h5>
                        </a>
                        <div class="progress mt-3 mb-2" style="height: 5px;">
                           <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" style="width: 25.1666666666667%" aria-valuenow="4.1666666666667" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <span>২৫% সম্পন্ন হয়েছে</span>
                        <div class="rating your-rating-box text-right" style="position: unset; margin-top: -18px;">
                           <i class="fa fa-star-o filled"></i>
                           <i class="fa fa-star-o filled"></i>
                           <i class="fa fa-star-o filled"></i>
                           <i class="fa fa-star-o filled"></i>
                           <i class="fa fa-star-o"></i>
                        </div>
						<div class="row pt-1">
						<div class="col-md-12"><span>কোর্স ফিঃ &nbsp <del><?php echo $course['course_price'].'TK'; ?></del>&nbsp<?php echo $course['course_discount_price'].'TK'; ?></span></div>
						</div>
                        <div class="row pt-2">						
                           <div class="col-md-6 pt-1">
                              <a href="course-details.php?id=<?php echo $course['course_id'] ?>" class="badge badge-success text-dark p-2">Show details</a>
                           </div>
                           <div class="col-md-6 text-right">
                              <a href="#" class="btn btn-sm btn-dark">Enroll Now</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
			
			<?php }} ?>
			
         </div>
      </div>
   </div>
</div>
<?php include 'footer.php'; ?>