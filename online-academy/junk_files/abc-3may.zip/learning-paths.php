<section class="section path-section">
					<div class="learning-path-col">
						<div class="container">						
						<div class="section-header text-center">
							<h2 class="myfont fs50">জনপ্রিয় কোর্স ক্যাটাগরি </h2></div>
							<br>
							<div class="row">
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/dm.jpg" alt="">
												<div class="text-col">
												<h5 class="cat_count">১১১</h5>
													<h5 class="myfont fs36">গ্রাফিক্স ডিজাইন </h5></div>
											</div>
										</a>
									</div>
								</div>
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/ud.jpg" alt="">
												<div class="text-col">
													<h5 class="cat_count">৩৩</h5>
													<h5 class="myfont fs36">ওয়েব ডিজাইন </h5></div>
											</div>
										</a>
									</div>
								</div>
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/is.jpg" alt="">
												<div class="text-col">
														<h5 class="cat_count">৪৩</h5>
													<h5 class="myfont fs36">ডিজিটাল মার্কেটিং  </h5></div>
											</div>
										</a>
									</div>
								</div>
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/fed.jpg" alt="">
												<div class="text-col">
													<h5 class="cat_count">৩৮</h5>
													<h5 class="myfont fs36">ভিডিও এডিটিং </h5></div>
											</div>
										</a>
									</div>
								</div>
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/wd.jpg" alt="">
												<div class="text-col">
												    	<h5 class="cat_count">৪৮</h5>
													<h5 class="myfont fs36">ফেইসবুক মার্কেটিং  </h5></div>
											</div>
										</a>
									</div>
								</div>
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/adm.jpg" alt="">
												<div class="text-col">
													<h5 class="cat_count">৪</h5>
													<h5 class="myfont fs36">ইউটউব মার্কেটিং  </h5></div>
											</div>
										</a>
									</div>
								</div>
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/pm.jpg" alt="">
												<div class="text-col">
													<h5 class="cat_count">৮</h5>
													<h5 class="myfont fs36">ডাটা এন্ট্রি  </h5></div>
											</div>
										</a>
									</div>
								</div>
								<div class="col-12 col-md-4 col-lg-3">
									<div class="large-col">
										<a href="#" class="large-col-image">
											<div class="image-col-merge"><img src="images/pd.jpg" alt="">
												<div class="text-col">
													<h5 class="cat_count">৮</h5>
													<h5 class="myfont fs36">স্পোকেন ইংলিশ </h5></div>
											</div>
										</a>
									</div>
								</div>
							</div></div>
					</div>
				</section>