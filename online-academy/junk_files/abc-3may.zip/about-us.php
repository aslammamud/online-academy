

<?php include'header.php'; ?>


<div style="background-color: green; height: 10px;"></div>
<section id="title">
    <center><div><h3>আমাদের সম্পর্কে</h3></div></center>
</section>
<style type="text/css">
    #title div{
        width: 100%;
        height: 80px;
        padding: 30px;
        background-color: #a4d68e;

    }
</style>


    <center>
        <section id="about-us">

        <div class="container">

  <h1 style="margin-top: 30px; margin-bottom: 30px;">About Us</h1>

     <div class="container1" >
        

  
  <div class="row">
    <div class="col-sm-4">
      <div class="card">
        <img class="card-img-top" src="./images/pd.jpg" height="250">
       
      </div>
    </div>
    <div class="col-sm-8">
      <div class="card">
        
        <p class="card-block">
          Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.
        </p>
      </div>
    </div>
    
    
  </div>



    </div>
      <center><div class="container2">
        

 
  
  <div class="row">
    
    <div class="col-sm-8">
      <div class="card">
        
        <p class="card-block">
            <h3>OUR MISSION</h3>
          Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.
        </p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="card">
        <img class="card-img-top" src="./images/pd.jpg">
       
      </div>
    </div>
    
    
  </div>


    </div>



    <div class="container2" >
        

  
  <div class="row">
    <div class="col-sm-4">
      <div class="card">
        <img class="card-img-top" src="./images/pd.jpg">
       
      </div>
    </div>
    <div class="col-sm-8">
      <div class="card">
        
        <p class="card-block">
            <h3>OUR VISION</h3>
          Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et Malorum for use in a type specimen book.
        </p>
      </div>
    </div>
    
    
  </div>



    </div>
    </center>
    
    
  </div>

  
  
  

</section>
</center>


<div class="like">
      <center><h2>Why Will You Choose Us</h2></center>
      
            <ul>
                <li><h4>There you have it: a simple JavaScript</h4></li>
                <li><h4>There you have it: a simple JavaScript</h4></li>
                <li><h4>There you have it: a simple JavaScript</h4></li>
                <li><h4>There you have it: a simple JavaScript</h4></li>
                <li><h4>There you have it: a simple JavaScript</h4></li>
                <li><h4>There you have it: a simple JavaScript</h4></li>
                <li><h4>There you have it: a simple JavaScript</h4></li>
                <li><h4>There you have it: a simple JavaScript</h4></li>
            </ul>
          
  </div>

    <style type="text/css">
    	h2{
    		text-align: center;
    		margin-top: 30px;
    		font-weight: 600;
    		text-decoration: none;
    	}
    #about-us .container .container1 .card{
        border: none;
    }

    #about-us .container .container1 .card img{

        height: 250px;
    }


    #about-us .container .container2{
        margin-top: 100px;
    }


    #about-us .container .container2 .card{
        border: none;
    }

    #about-us .container .container2 .card img{

        height: 250px;
    }


    #about-us .container .container3 .card{
        border: none;
    }

    #about-us .container .container3 .card img{

        height: 250px;
    }



        .like li{
            margin-top: 20px;
            margin-left: 30px;
        }
        .like h2{
            margin-bottom: 50px;
        }
        .like{
            margin-bottom: 50px;
        }


       


    	
    </style>

<?php include'footer.php'; ?>