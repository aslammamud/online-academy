<style>
    
    ul li a ,a{
       color:#000 !important;
    }
    
    li.side-nav-item.active.pl-2.pt-3.pb-3 span {
    color: #fff;
    }
    
    li.side-nav-item.active.pl-2.pt-3.pb-3 {
        background: #7ddb55;
    }
    
    
</style>

<?php

    $ins_id = $_SESSION['abc_ins_id'];

    $query = "SELECT * FROM instructor WHERE ins_id = '$ins_id'";
    $res = mysqli_query($con,$query);
    //$cnt = mysqli_num_rows($res);
    $instructor = mysqli_fetch_assoc($res);
?>

<div class="col-md-3">
    <div class="card-eader">
        
        <div class="left-side-menu left-side-menu-detached bg-light">
            <div class="leftbar-user text-center">
                <a href="#">
                    
                    <?php if($instructor['ins_photo']== ""){
                        echo '<img width="80px" src="../upload/instructor-profile/default_instructor.jpg" alt="user-image" class="rounded-circle shadow-sm mt-3">';
                    }else{
                        echo '<img width="80px" src="../upload/instructor-profile/'.$instructor['ins_photo'].'" alt="user-image" class="rounded-circle shadow-sm mt-3">';
                    }
                    ?>
                   
                    <h5 class="leftbar-user-name text-center mt-2"><?=$instructor['ins_name']?></h5>
                </a>
            </div>
            
             <ul class="metismenu side-nav side-nav-light">       
             <li class="side-nav-title side-nav-item text-secondary mb-2 h5"><hr></li>

<?php
    
    if($instructor['ins_verified'] == false) {
        

?>
            <li class="side-nav-item pl-2 pt-3 pb-3">
                <a href="instructor/" class="side-nav-link active">
                    <i class="fa fa-th tx-2x text-secondary"></i>
                    <span class="h6 pl-1"><strong>Dashboard</strong></span>
                </a>
            </li>
            <li class="side-nav-item pl-2 pt-3 pb-3">
                <a href="instructor/notifications.php" class="side-nav-link active">
                    <i class="fa fa-bell-o tx-2x text-secondary"></i>
                    <span class="h6 pl-1"><strong>Notifications</strong></span>
                </a>
            </li>
            
            <li class="side-nav-item pl-2 pt-3 pb-3">
                <a href="instructor/profile.php" class="side-nav-link active">
                    <i class="fa fa-user tx-2x text-secondary"></i>
                    <span class="h6 pl-1"><strong>Manage profile</strong></span>
                </a>
            </li>            
            <li class="side-nav-item pl-2 pt-3 pb-3">
                <a href="instructor/logout.php" class="side-nav-link active">
                    <i class="fa fa-power-off tx-2x text-secondary"></i>
                    <span class="h6 pl-1"><strong>Logout</strong></span>
                </a>
            </li>

<?php

    }else{
    
?>
                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/" class="side-nav-link active">
                        <i class="fa fa-th tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Dashboard</strong></span>
                    </a>
                </li>

                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/course-manage.php" class="side-nav-link active">
                        <i class="fa fa-shopping-basket tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Course manager</strong></span>
                    </a>
                </li>

                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/add-new-course.php" class="side-nav-link active">
                        <i class="fa fa-plus-square tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Add New Course</strong></span>
                    </a>
                </li>

                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/add-new-category.php" class="side-nav-link active">
                        <i class="fa fa-plus-square tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Add New Category</strong></span>
                    </a>
                </li>

                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/add-new-sub-catg.php" class="side-nav-link active">
                        <i class="fa fa-plus-square tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Add New Sub Category</strong></span>
                    </a>
                </li>
                
<!--                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/sales_report.php" class="side-nav-link active">
                        <i class="fa fa-tachometerfa fa-calendar-minus-o tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Sales report</strong></span>
                    </a>
                </li>

                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/payout_report.php" class="side-nav-link active">
                        <i class="fa fa-money tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Payout report</strong></span>
                    </a>
                </li>

                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/payout_settings.php" class="side-nav-link active">
                        <i class="fa fa-cog tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Payout settings</strong></span>
                    </a>
                </li>-->

<!--                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="#" class="side-nav-link active">
                        <i class="fa fa-envelope-o tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Message</strong></span>
                    </a>
                </li>-->
            
                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/notifications.php" class="side-nav-link active">
                        <i class="fa fa-bell-o tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Notifications</strong></span>
                    </a>
                </li>

                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/profile.php" class="side-nav-link active">
                        <i class="fa fa-user tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Manage profile</strong></span>
                    </a>
                </li>            
                <li class="side-nav-item pl-2 pt-3 pb-3">
                    <a href="instructor/logout.php" class="side-nav-link active">
                        <i class="fa fa-power-off tx-2x text-secondary"></i>
                        <span class="h6 pl-1"><strong>Logout</strong></span>
                    </a>
                </li>
                
                
                
<?php

    }

?>
            </ul>
        </div>

    </div>
</div>