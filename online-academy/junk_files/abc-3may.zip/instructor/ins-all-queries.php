<?php
    
/*    function getCourses(){
        $sql = "";
        $result = mysqli_query($con,$sql);   
        $data = mysqli_fetch_assoc($result);
        $count = mysqli_num_rows($result);
        
        if($count>0){
        	
        	foreach($result as $data){
        	}
        }
    }  */  
    
    //getCount('instructor','ins_id', 34);
    function getCount($table , $col, $val){
 
        if($val == '1'){
            
            $sql_qr = "SELECT * FROM"." ".$table;
            $sql_result = mysqli_query($con,$sql_qr);
            $count = mysqli_num_rows($sql_result);
            
            if($count>0){
            	echo $count;
            }
        }else{
            $sql = "SELECT * FROM '$table' WHERE '$col' = '$val'";
            $result = mysqli_query($con,$sql);
            $count = mysqli_num_rows($result);
            
            if($count>0){
            	echo $count;
            }
        }
        

    }

        
?>