<?php include('header.php') ?>
        <div class="content">
            <div class="container-fluid">
           <p>DUE PAYMENTS LIST</p>
 <div class="row">
                   <div class="col-md-2 stat_box bg_green">
					<h2>00</h2>
					<p>Due This Month</P>
					    </div>
				 <div class="col-md-2 stat_box bg_green">
					<h2>00</h2>
					<p>Total Due Payment</P>
					    </div>
	</div>

		   <div class="row">
                   <div class="col-12">
                        <div class="card">
                            <div class="card-body">

                            <div class="general-label" style="background:black; padding:10px; margin-bottom:20px;">
                                    <form class="form-inline" role="form">
                                        <div class="form-group m-2"><input type="text" placeholder="STUDENT ID" name="REG_no" class="form-control"> </div>
                                        <div class="form-group"><input type="text" placeholder="MOBILE NUMBER" name="REG_no" class="form-control"> </div>
                                        <div class="form-group  m-2"><input type="text" placeholder="STUDENT NAME" name="REG_no" class="form-control"> </div>
                                        <div class="form-group"><input type="text" placeholder="BATCH NUMBER" name="REG_no" class="form-control"> </div>
                                            
                                     
                                        <button type="submit" class="btn btn-success ml-2">SEACH</button>
                                    </form>           
                                </div>
                             
                                <div class="table-rep-plugin">
                                    <div class="table-wrapper"><div class="table-responsive b-0" data-pattern="priority-columns">
                                        <div class="sticky-table-header fixed-solution">
										<table id="tech-companies-1-clone" class="table  table-striped">
                                            <thead class="thead-dark">
                                            <tr>
                                                <th id="tech-companies-1-col-0-clone">J.DATE</th>
                                                <th id="tech-companies-1-col-0-clone">ID</th>
												<th data-priority="1" id="tech-companies-1-col-1-clone">STD.ID</th>
                                                <th data-priority="1" id="tech-companies-1-col-1-clone">NAME</th>
                                                <th data-priority="3" id="tech-companies-1-col-2-clone">COURSE</th>
                                                <th data-priority="1" id="tech-companies-1-col-3-clone">PAYMENT</th>
                                                <th data-priority="3" id="tech-companies-1-col-4-clone">GATEWAY</th>
                                                <th data-priority="3" id="tech-companies-1-col-5-clone">REF</th>
                                                <th data-priority="6" id="tech-companies-1-col-6-clone">NUMBER</th>
                                                <th data-priority="6" id="tech-companies-1-col-7-clone">OPT</th>
                                            </tr>
                                            </thead>
                                            <tbody>
 
											
											<tr> 
		  <th scope="row">2021-03-29 20:24:46</th> 
		  <th>5015</th> 
		  <th>14415</th> 
		  <td>Md.Ruhul Amin</td> 
		  <td>Digital Marketing</td> 
		  <td><span class="badge p-1 badge-info">Due (750)</span><br><span class="badge p-1 badge-success">Paid (750)</span></td> 
		  <td>bkash</td>
		  <td>munnahossain</td>
		  <td>01862651017</td>
			  <td>
		  
		  <button type="button" class="btn btn-dark btn-transparent btn-theme-colored btn-sm" data-toggle="modal" data-target=".bs-example-modal-lg-14415">View</button>
		  <a href="https://www.online.pixelitinst.com/dashboard/edit-payment.php?st=5015" class="btn btn-success  btn-sm">Payment</a>
		  <a href="https://www.online.pixelitinst.com/dashboard/edit-online-student.php?st=5015" class="btn btn-dark btn-transparent btn-theme-colored btn-sm">Edit</a>
<a href="https://www.online.pixelitinst.com/dashboard/delete-form.php?st=5015" class="btn btn-danger  btn-sm">Delete</a>

<div class="modal fade bs-example-modal-lg-14415" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg">
   
   
   
   <div data-example-id="contextual-table" style="background: #FFF;
margin: 0 auto;
border-top: 5px solid #51504d;
border-radius: 4px;" class="bs-example col-md-8 col-md-push-2">
<h3 style="text-align:center;">Digital IT Online Students</h3>	
			<div style="width:200px; height:200px; margin:0 auto;"><img src="img/avater.png" class="mb-20 img-thumbnail"></div>
			<br>
			<table class="table"> 
	<tbody>
			<tr class="active"> 
			<th scope="row">Full Name:		
			
			</th> 
			<td>Md.Ruhul Amin</td> 
			<th scope="row">Phone:</th>  
			<td>01862651017</td> </tr>
			
			
			<tr> <th scope="row">Registration: 
			</th> <td>14415</td> 
			<th scope="row">Payment :</th>  
			<td><span class="label"><span class="badge p-1 badge-success btn-sm">Paid</span></span></td> </tr>
			<tr class="success"> 
			<th scope="row">Course Name: </th> 
			<td>Digital Marketing</td> 
			<th scope="row">Date of Birth :</th> 
			<td></td> </tr>
			
			 <tr class="active"> 
			<th scope="row">Batch No:</th> 
			<td>2110</td> 
			<th scope="row">Reference:</th>  
			<td>munnahossain</td> </tr> 
			
			</tbody> 
	 
	</table> 
			<div class="row">
                      <div class="col-sm-6">
                       <a href="download-form.php?st=5015" target="_blank" class="btn btn-block btn-info btn-sm mt-20 pt-10 pb-10">
					   DOWNLOAD FORM</a>
                      </div>
                      <div class="col-sm-6">
                       <a href="invoice.php?st=5015" target="_blank" class="btn btn-block btn-success btn-sm mt-20 pt-10 pb-10">
					   VIEW INVOICE</a>
                      </div>
                    </div><br>
 
              </div>
   
   
   
   
   
   
  </div>
</div></td> 
		  </tr>          		  
		   
											
											
											
                                               
                                        
                                            </tbody>
                                        </table>
										<nav aria-label="...">
                             <ul class="pagination"><li class="details">Page 1 of 9</li><li><a href="?page=1" class="current">1</a></li><li><a href="?page=2">2</a></li><li><a href="?page=3">3</a></li><li><a href="?page=4">4</a></li><li><a href="?page=5">5</a></li><li><a href="?page=6">6</a></li><li><a href="?page=7">7</a></li><li><a href="?page=8">8</a></li><li><a href="?page=9">9</a></li><li><a href="?page=2">Next</a></li><li><a href="?page=9">Last</a></li></ul>
                                </nav>
                                    </div></div>

                                </div>

                            </div>
                        </div>
                    </div>
                   </div><!--end row-->

              
             </div>
             </div>
        </div>

<?php include('footer.php') ?>