
    <script src="lib-admin/jquery/jquery.js"></script>
    <script src="lib-admin/popper.js/popper.js"></script>
    <script src="lib-admin/bootstrap/bootstrap.js"></script>
    <script src="lib-admin/jquery-ui/jquery-ui.js"></script>
    <script src="lib-admin/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
    <script src="lib-admin/jquery.sparkline.bower/jquery.sparkline.min.js"></script>
    <script src="lib-admin/d3/d3.js"></script>
    <script src="lib-admin/rickshaw/rickshaw.min.js"></script>
    <script src="lib-admin/chart.js/Chart.js"></script>
    <script src="lib-admin/Flot/jquery.flot.js"></script>
    <script src="lib-admin/Flot/jquery.flot.pie.js"></script>
    <script src="lib-admin/Flot/jquery.flot.resize.js"></script>
    <script src="lib-admin/flot-spline/jquery.flot.spline.js"></script>

    <script src="js/starlight.js"></script>
    <script src="js/ResizeSensor.js"></script>
    <script src="js/dashboard.js"></script>
  </body>
</html>