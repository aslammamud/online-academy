<?php
include 'left-panel.php';
include 'head-panel.php';
include 'right-panel.php';
?>