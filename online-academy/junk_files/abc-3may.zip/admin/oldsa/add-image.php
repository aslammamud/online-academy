<?php include 'header.php'; ?>

<!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
    
      </nav>

      <div class="sl-pagebody">  
        <div class="row row-sm mg-t-20">
          <div class="col-lg-6">
            <div class="card">


      <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 bg-white m-auto">
        <div class="signin-logo tx-center tx-24 tx-bold tx-inverse">Add New <span class="tx-info tx-normal">Offer Image</span></div>
      

       
        <div class="form-group">
          <input type="file" class="form-control" placeholder="">
          
        </div><!-- form-group -->
        <button type="submit" class="btn btn-info btn-block">Upload</button>

        
      </div><!-- login-wrapper -->
    </div><!-- d-flex -->
         
            </div>
             <div class="col-lg-6">
            <div class="card">


      <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 bg-white m-auto">
        <div class="signin-logo tx-center tx-24 tx-bold tx-inverse">Add Home  <span class="tx-info tx-normal">Slider Image</span></div>
       

        
        <div class="form-group">
          <input type="file" class="form-control" placeholder="">
       
        </div><!-- form-group -->
        <button type="submit" class="btn btn-info btn-block">Upload</button>

        
      </div><!-- login-wrapper -->
    </div><!-- d-flex -->
         
            </div>
        <div class="col-lg-6 mg-t-20 mg-lg-t-0">
            <div class="card">
              <div class="card-header pd-20 bg-transparent bd-b bd-gray-200">
                <h6 class="card-title tx-uppercase tx-12 mg-b-0">History</h6>
              </div><!-- card-header -->
              <table class="table table-white table-responsive mg-b-0 tx-12">
                <thead>
                  <tr class="tx-10">
                  
                       <td>image  </td>
                        <td>image name  </td>
                         <td>image  id </td>
                           <td> </td>
                            <td> </td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="pd-l-20">
                      <img src="../img/img23.jpg" class="wd-55" alt="Image">
                    </td>
                    <td>
                      <a href="" class="tx-inverse tx-14 tx-medium d-block">The Dothraki Shoes</a>
                      <span class="tx-11 d-block"><span class="square-8 bg-danger mg-r-5 rounded-circle"></span> 20 remaining</span>
                    </td>
                    <td class="valign-middle tx-right">3,345</td>
                    <td class="valign-middle"><span class="tx-success"><i class="icon ion-android-arrow-up mg-r-5"></i>33.34%</span> from last week</td>
                    <td class="valign-middle tx-center">
                      <a href="" class="tx-gray-600 tx-24"><i class="icon ion-android-more-horizontal"></i></a>
                    </td>
                
                 </tr>
                </tbody>
              </table>
             
            </div><!-- card -->
          </div><!-- col-6 -->
           
          <div class="col-lg-6 mg-t-20 mg-lg-t-0">
            <div class="card">
              <div class="card-header pd-20 bg-transparent bd-b bd-gray-200">
                <h6 class="card-title tx-uppercase tx-12 mg-b-0">History</h6>
              </div><!-- card-header -->
              <table class="table table-white table-responsive mg-b-0 tx-12">
                <thead>
                  <tr class="tx-10">
                  
                       <td>image  </td>
                        <td>image name  </td>
                         <td>image  id </td>
                           <td> </td>
                            <td> </td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="pd-l-20">
                      <img src="../img/img23.jpg" class="wd-55" alt="Image">
                    </td>
                    <td>
                      <a href="" class="tx-inverse tx-14 tx-medium d-block">The Dothraki Shoes</a>
                      <span class="tx-11 d-block"><span class="square-8 bg-danger mg-r-5 rounded-circle"></span> 20 remaining</span>
                    </td>
                    <td class="valign-middle tx-right">3,345</td>
                    <td class="valign-middle"><span class="tx-success"><i class="icon ion-android-arrow-up mg-r-5"></i>33.34%</span> from last week</td>
                    <td class="valign-middle tx-center">
                      <a href="" class="tx-gray-600 tx-24"><i class="icon ion-android-more-horizontal"></i></a>
                    </td>
                
                 </tr>
                </tbody>
              </table>
             
            </div><!-- card -->
          </div><!-- col-6 -->
           
    <!-- ########## END: MAIN PANEL ########## -->

<?php
  require_once 'footer.php';
?>

