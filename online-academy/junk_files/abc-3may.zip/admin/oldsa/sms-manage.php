<?php  
include 'header.php';
?>

    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
      <nav class="breadcrumb sl-breadcrumb">
        <a class="breadcrumb-item" href="sms-manage.php">SMS/Notification Manage</a>
      </nav>

      <div class="col-lg-12 sl-pagebody">
        <h5 class="text-left text-warning">Notification Manage</h5>
        <div class="row my-4">
            <div class="col-md-3 bg-info text-white">
                <div class="">
                    <div class="row">
                        <div class="col-md-4">
                            <img class="rounded-circle mt-3" width="50" height="50" src="../img/img12.jpg" alt="img not found">
                        </div>
                        <div class="col-md-8">        
                            <p class="mt-2">Saiful Islam Sobuj</p>
                            <p>saiful@gmail.com</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8 bg-info text-white ml-auto">
                fdgsdfgsdfg sdfgsdf sdfg sdfg sdfg gf fdgsdfgsdfg sdfgsdf sdfg sdfg sdfg gf
            </div>
        </div>

      </div><!-- sl-pagebody -->
    </div><!-- sl-mainpanel --> 

  


    <!-- ########## END: MAIN PANEL ########## -->

<?php
  require_once 'footer.php';
?>
