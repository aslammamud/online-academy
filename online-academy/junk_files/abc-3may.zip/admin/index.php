<?php include('header.php') ?>
        <div class="content">
            <div class="container-fluid">
			
		<?php include('part-awerd.php') ?>			
		<?php include('part-adm-stats.php') ?>			
			
			



              </div>
        </div>

<?php include('footer.php') ?>