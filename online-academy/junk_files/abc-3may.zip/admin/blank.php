<?php include('header.php') ?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                 
				 
				 </div>
             </div>
        </div>

<?php include('footer.php') ?>