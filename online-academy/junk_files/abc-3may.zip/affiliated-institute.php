<style>

</style>

<section class="speaker-one">


			<div class="container">
				<div class="row">
					<div class="col-md-12 col-lg-5">
						<div class="section-title mt-50">
							<h2 class="myfont fs50" style="color:#08a829"><span style="color:#08a829" class="myfont fs50">আমাদের সাথে </span>এফিলিয়েটেড ইনস্টিটিউট </h2>
							<p  class="abc_normal_text" style="font-size:19px;">আমরা বাংলাদেশের স্বনামধন্য আইটি ইনস্টিটিউট গুলোর সাথে চুক্তিবদ্ধ হয়ে কাজ করছি আইটি দক্ষতা সর্বস্তরে পৌঁছে দেওয়ার জন্য।  </p>
							<a class="section-link" href="#">See Full List <i class="fa fa-chevron-right" aria-hidden="true"></i></a>
						</div>
					</div>
					<!-- /.col-md-5 -->
					<div class="col-md-12 col-lg-7">
						<div class="speaker-one-inner">
							<ul>
								<li>
									<a href="#">
										<div class="speaker-box">
											<div class="speaker-info">
												<h4>eMoktob</h4>
												<span>Arbi Online Education</span>
											</div>
											<svg version="1.1" class="svg top-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 356.3 313.6" xml:space="preserve">
										<g>
											<defs>
												<polygon points="-196.9,11.3 -364.9,11.3 -448.8,156.8 -364.9,302.3 -196.9,302.3 -112.9,156.8"></polygon>
											</defs>
											<g>

												<image width="334" height="291" xlink:href="684C3EF0.jpg" transform="matrix(1.0276 0 0 1.0276 -452.4791 7.2722)"></image>
											</g>
										</g>
										<polygon points="262.1,11.3 94.1,11.3 10.2,156.8 94.1,302.3 262.1,302.3 346.1,156.8 "></polygon>
									</svg>

											<div class="speaker-img">
												<img class="speaker-image" src="images/emoktob.jpg
" alt="">
											</div>

										</div>
									</a>
									<span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 142.7 127" style="enable-background:new 0 0 142.7 127; fill:transparent;" xml:space="preserve" class="svg speaker-small">

							<polygon points="98.2,17.8 43.8,17.8 16.7,64.9 43.8,111.9 98.2,111.9 125.4,64.9 "></polygon>
							</svg></span>
								</li>

								<li>
									<a href="#">
										<div class="speaker-box">
											<div class="speaker-info">
												<h4>Pixel IT Institute</h4>
												<span>Best Online Education </span>
											</div>
											<svg version="1.1" class="svg top-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 356.3 313.6" xml:space="preserve">
									<g>
										<defs>
											<polygon points="-196.9,11.3 -364.9,11.3 -448.8,156.8 -364.9,302.3 -196.9,302.3 -112.9,156.8 		"></polygon>
										</defs>
										<g>

											<image width="334" height="291" xlink:href="684C3EF0.jpg" transform="matrix(1.0276 0 0 1.0276 -452.4791 7.2722)">
											</image>
										</g>
									</g>
									<polygon points="262.1,11.3 94.1,11.3 10.2,156.8 94.1,302.3 262.1,302.3 346.1,156.8 "></polygon>
								</svg>
											<div class="speaker-img">
												<img class="speaker-image" src="images/speakers/hh3.png" alt="">
											</div>
										</div>
									</a>
									<span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 142.7 127" style="enable-background:new 0 0 142.7 127; fill:transparent;" xml:space="preserve" class="svg speaker-small">

								<polygon points="98.2,17.8 43.8,17.8 16.7,64.9 43.8,111.9 98.2,111.9 125.4,64.9"></polygon>
								</svg></span>
								</li>

								<li>
									<a href="#">
										<div class="speaker-box">
											<div class="speaker-info">
												<h4>100 Miles IT</h4>
												<span>BEST IT </span>
											</div>
											<svg version="1.1" class="svg top-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 356.3 313.6" xml:space="preserve">
								<g>
									<defs>
										<polygon points="-196.9,11.3 -364.9,11.3 -448.8,156.8 -364.9,302.3 -196.9,302.3 -112.9,156.8 "></polygon>
									</defs>
									<g>

										<image width="334" height="291" xlink:href="684C3EF0.jpg" transform="matrix(1.0276 0 0 1.0276 -452.4791 7.2722)">
										</image>
									</g>
								</g>
								<polygon points="262.1,11.3 94.1,11.3 10.2,156.8 94.1,302.3 262.1,302.3 346.1,156.8 "></polygon>
							</svg>
											<div class="speaker-img">
												<img class="speaker-image" src="images/speakers/hh4.png" alt="">
											</div>
										</div>
									</a>
									<span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 142.7 127" style="enable-background:new 0 0 142.7 127; fill:transparent;" xml:space="preserve" class="svg speaker-small">

								<polygon points="98.2,17.8 43.8,17.8 16.7,64.9 43.8,111.9 98.2,111.9 125.4,64.9 "></polygon>
								</svg></span>
								</li>

								<li>
									<a href="#">
										<div class="speaker-box">
											<div class="speaker-info">
												<h4>Digital IT Institute</h4>
												<span>Best Online/OFFline IT</span>
											</div>
											<svg version="1.1" class="svg top-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 356.3 313.6" xml:space="preserve">
							<g>
								<defs>
									<polygon points="-196.9,11.3 -364.9,11.3 -448.8,156.8 -364.9,302.3 -196.9,302.3 -112.9,156.8 		"></polygon>
								</defs>
								<g>

									<image width="334" height="291" xlink:href="684C3EF0.jpg" transform="matrix(1.0276 0 0 1.0276 -452.4791 7.2722)">
									</image>
								</g>
							</g>
							<polygon points="262.1,11.3 94.1,11.3 10.2,156.8 94.1,302.3 262.1,302.3 346.1,156.8 "></polygon>
						</svg>
											<div class="speaker-img">
												<img class="speaker-image" src="images/speakers/h11.png" alt="">
											</div>
										</div>
									</a>
								</li>

								<li>
									<a href="#">
										<div class="speaker-box">
											<div class="speaker-info">
												<h4>ITvisionBD</h4>
												<span>NTEB Approved</span>
											</div>
											<svg version="1.1" class="svg top-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 356.3 313.6" xml:space="preserve">
						<g>
							<defs>
								<polygon points="-196.9,11.3 -364.9,11.3 -448.8,156.8 -364.9,302.3 -196.9,302.3 -112.9,156.8 		"></polygon>
							</defs>
							<g>
								<image width="334" height="291" xlink:href="684C3EF0.jpg" transform="matrix(1.0276 0 0 1.0276 -452.4791 7.2722)">
								</image>
							</g>
						</g>
						<polygon points="262.1,11.3 94.1,11.3 10.2,156.8 94.1,302.3 262.1,302.3 346.1,156.8 "></polygon>
					</svg>
											<div class="speaker-img">
												<img class="speaker-image" src="images/speakers/hh5.png" alt="">
											</div>
										</div>
									</a>
								</li>
							</ul>
						</div>
					</div>
					<!-- /.col-md-7 -->
				</div>
				<!-- /.row -->
			</div>
			<!-- /.container -->
		</section>