<?php

  include ('student-header.php');

?>

<section class="purchase-history-list-area bg-light">
    <div class="container">
        <div class="row">
            <div class="col">
                <ul class="purchase-history-list">
                    <li class="purchase-history-list-header">
                        <div class="row">
                            <div class="col-sm-6"><h4 class="purchase-history-list-title"> ক্রয়কৃত কোর্সের বর্ণনা </h4></div>
                            <div class="col-sm-6 hidden-xxs hidden-xs">
                                <div class="row">
                                    <div class="col-sm-3"> তারিখ </div>
                                    <div class="col-sm-3"> মোট টাকা </div>
                                    <div class="col-sm-4"> অর্থ প্রদানের ধরণ </div>
                                    <div class="col-sm-2"> কার্যক্রম </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="purchase-history-items mb-2">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="purchase-history-course-img">
                                    <img style="width:130px; height:130px;" src="../images/course-x.jpg" class="img-fluid">
                                </div>
                                <a class="purchase-history-course-title" href="##">
                                 <!-- http://demo.academy-lms.com/default/home/course/user-experience-design-essentials-adobe-xd-ui-ux-design/15 -->
                                    PHP দিয়ে ওয়ার্ডপ্রেস থিম ডেভেলপমেন্ট কোর্স - সম্পূর্ণ বাংলায়
                                </a>
                            </div>
                            <div class="col-sm-6 purchase-history-detail">
                                <div class="row">
                                    <div class="col-sm-3 date">
                                        Tue, 09-Mar-2021
                                    </div>
                                    <div class="col-sm-3 price">
                                        <b>৳ ৪০০</b>
                                    </div>
                                    <div class="col-sm-4 payment-type">
                                        Bkash
                                    </div>
                                    <div class="col-sm-2">
                                        <a href="invoice.php" target="_blank" class="btn btn-receipt">Invoice</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="purchase-history-items mb-2">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="purchase-history-course-img">
                                    <img style="width:130px; height:130px;" src="../images/pd.jpg" class="img-fluid">
                                </div>
                                <a class="purchase-history-course-title" href="##">
                                 <!-- http://demo.academy-lms.com/default/home/course/how-to-shoot-b-roll-footage-with-peter-mckinnon/26 -->
                                    PHP লারাভেল ডেভেলপমেন্ট - সম্পূর্ণ বাংলায়
                                </a>
                            </div>
                            <div class="col-sm-6 purchase-history-detail">
                                <div class="row">
                                    <div class="col-sm-3 date">
                                        Tue, 09-Mar-2021
                                    </div>
                                    <div class="col-sm-3 price">
                                        <b>৳ ৪০০</b>
                                    </div>
                                    <div class="col-sm-4 payment-type">
                                        DBBL
                                    </div>
                                    <div class="col-sm-2">
                                        <a href="invoice.php" target="_blank" class="btn btn-receipt">Invoice</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                    <li class="purchase-history-items mb-2">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="purchase-history-course-img">
                                    <img style="width:130px; height:130px;" src="../images/pm.jpg" class="img-fluid">
                                </div>
                                <a class="purchase-history-course-title" href="##">
                                 <!-- http://demo.academy-lms.com/default/home/course/how-to-shoot-b-roll-footage-with-peter-mckinnon/26 -->
                                    PHP দিয়ে ওয়ার্ডপ্রেস থিম ডেভেলপমেন্ট কোর্স - সম্পূর্ণ বাংলায়
                                </a>
                            </div>
                            <div class="col-sm-6 purchase-history-detail">
                                <div class="row">
                                    <div class="col-sm-3 date">
                                        Tue, 09-Mar-2021
                                    </div>
                                    <div class="col-sm-3 price">
                                        <b>৳ ৪০০</b>
                                    </div>
                                    <div class="col-sm-4 payment-type">
                                        Bkash
                                    </div>
                                    <div class="col-sm-2">
                                        <a href="invoice.php" target="_blank" class="btn btn-receipt">Invoice</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</section>


<?php include '../footer.php'; ?>

