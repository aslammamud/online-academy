<?php

  include ('student-header.php');

?>
<div class="container-fluid">
    <div class="row my-4">
      <div class="col-md-12">
        <div class="row">
          <div class="col-md-9 custom-btn">
            <button class="btn btn-success">Enrolled Courses</button>
          </div>
          <div class="col-md-3 ml-auto mb-4 text-right">
            <div class="my-course-search-bar">
              <form action="">
                  <div class="input-group">
                      <input type="text" class="form-control" placeholder="কোর্স খুঁজুন  " onkeyup="getCoursesBySearchString(this.value)">
                      <div class="input-group-append">
                          <button class="btn btn-light" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                      </div>
                  </div>
              </form>
            </div>
          </div>

        </div>
      </div>                                              
    </div>

    <div class="row my-4">
      <div class="col-md-12">
        <div class="row">

          <div class="col-md-3">
            <div class="card bg-light">
              <img class="card-img-top" src="../images/ABC-Academy-sir2.png" alt="img">
              <div class="custom-card card-body">
                <div class="course-details mt-2">
                    <a href=""><h5 class="title myfont fs26">ওয়েব ডেভেলপমেন্ট শিখুন ঘরে বসে..</h5></a>
                      <div class="progress mt-3 mb-2" style="height: 20px;">
                   <div class="progress-bar bg-success progress-bar-striped" style="width:40%;">70%</div>
                      </div>
                        <span>৮৫% সম্পন্ন হয়েছে</span>
                        <div class="rating your-rating-box text-right" style="position: unset; margin-top: -18px;">
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o"></i>
                          <!-- <p class="your-rating-text" id = "12" onclick="getCourseDetailsForRatingModal(this.id)">
                            <span class="your">Your</span>
                            <span class="edit">Edit</span>
                            Rating                                          
                          </p> -->
                       
                          <!-- <a href="javascript::" class="hidden" id="cancel_rating_btn_12" onclick="toggleRatingView('12')" style="color: #2a303b">Cancel rating</a> -->
                        </p>
                    </div>
                    <div class="row mb-2">
                      <div class="col-md-6">
                           <a href="#" class="btn btn-secondary myfont fs26"> বিস্তারিত </a>
                      </div>

                      <div class="col-md-6 text-right">
                        <a href="start-course.php" class="btn btn-sm btn-outline-secondary myfont fs26">শিখা শুরু করুন </a>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <div class="card bg-light">
              <img class="card-img-top" src="../images/ABC-Academy-sir2.png" alt="img">
              <div class="custom-card card-body">
                <div class="course-details mt-2">
                    <a href=""><h5 class="title myfont fs26">ওয়েব ডেভেলপমেন্ট শিখুন ঘরে বসে..</h5></a>
                      <div class="progress mt-3 mb-2" style="height: 20px;">
                   <div class="progress-bar bg-success progress-bar-striped" style="width:40%;">70%</div>
                      </div>
                        <span>৮৫% সম্পন্ন হয়েছে</span>
                        <div class="rating your-rating-box text-right" style="position: unset; margin-top: -18px;">
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o"></i>
                          <!-- <p class="your-rating-text" id = "12" onclick="getCourseDetailsForRatingModal(this.id)">
                            <span class="your">Your</span>
                            <span class="edit">Edit</span>
                            Rating                                          
                          </p> -->
                       
                          <!-- <a href="javascript::" class="hidden" id="cancel_rating_btn_12" onclick="toggleRatingView('12')" style="color: #2a303b">Cancel rating</a> -->
                        </p>
                    </div>
                    <div class="row mb-2">
                      <div class="col-md-6">
                           <a href="#" class="btn btn-secondary myfont fs26"> বিস্তারিত </a>
                      </div>

                      <div class="col-md-6 text-right">
                        <a href="#" class="btn btn-outline-secondary myfont fs26">শিখা শুরু করুন </a>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3">
           <div class="card bg-light">
              <img class="card-img-top" src="../images/ABC-Academy-sir2.png" alt="img">
              <div class="custom-card card-body">
                <div class="course-details mt-2">
                    <a href=""><h5 class="title myfont fs26">ওয়েব ডেভেলপমেন্ট শিখুন ঘরে বসে..</h5></a>
                      <div class="progress mt-3 mb-2" style="height: 20px;">
                   <div class="progress-bar bg-success progress-bar-striped" style="width:40%;">70%</div>
                      </div>
                        <span>৮৫% সম্পন্ন হয়েছে</span>
                        <div class="rating your-rating-box text-right" style="position: unset; margin-top: -18px;">
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o"></i>
                          <!-- <p class="your-rating-text" id = "12" onclick="getCourseDetailsForRatingModal(this.id)">
                            <span class="your">Your</span>
                            <span class="edit">Edit</span>
                            Rating                                          
                          </p> -->
                       
                          <!-- <a href="javascript::" class="hidden" id="cancel_rating_btn_12" onclick="toggleRatingView('12')" style="color: #2a303b">Cancel rating</a> -->
                        </p>
                    </div>
                    <div class="row mb-2">
                      <div class="col-md-6">
                           <a href="#" class="btn btn-secondary myfont fs26"> বিস্তারিত </a>
                      </div>

                      <div class="col-md-6 text-right">
                        <a href="#" class="btn btn-outline-secondary myfont fs26">শিখা শুরু করুন </a>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3">
            <div class="card bg-light">
              <img class="card-img-top" src="../images/ABC-Academy-sir2.png" alt="img">
              <div class="custom-card card-body">
                <div class="course-details mt-2">
                    <a href=""><h5 class="title myfont fs26">ওয়েব ডেভেলপমেন্ট শিখুন ঘরে বসে..</h5></a>
                      <div class="progress mt-3 mb-2" style="height: 20px;">
                   <div class="progress-bar bg-success progress-bar-striped" style="width:40%;">70%</div>
                      </div>
                        <span>৮৫% সম্পন্ন হয়েছে</span>
                        <div class="rating your-rating-box text-right" style="position: unset; margin-top: -18px;">
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o"></i>
                          <!-- <p class="your-rating-text" id = "12" onclick="getCourseDetailsForRatingModal(this.id)">
                            <span class="your">Your</span>
                            <span class="edit">Edit</span>
                            Rating                                          
                          </p> -->
                       
                          <!-- <a href="javascript::" class="hidden" id="cancel_rating_btn_12" onclick="toggleRatingView('12')" style="color: #2a303b">Cancel rating</a> -->
                        </p>
                    </div>
                    <div class="row mb-2">
                      <div class="col-md-6">
                           <a href="#" class="btn btn-secondary myfont fs26"> বিস্তারিত </a>
                      </div>

                      <div class="col-md-6 text-right">
                        <a href="#" class="btn btn-outline-secondary myfont fs26">শিখা শুরু করুন </a>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-3 mt-4">
           <div class="card bg-light">
              <img class="card-img-top" src="../images/ABC-Academy-sir2.png" alt="img">
              <div class="custom-card card-body">
                <div class="course-details mt-2">
                    <a href=""><h5 class="title myfont fs26">ওয়েব ডেভেলপমেন্ট শিখুন ঘরে বসে..</h5></a>
                      <div class="progress mt-3 mb-2" style="height: 20px;">
                   <div class="progress-bar bg-success progress-bar-striped" style="width:40%;">70%</div>
                      </div>
                        <span>৮৫% সম্পন্ন হয়েছে</span>
                        <div class="rating your-rating-box text-right" style="position: unset; margin-top: -18px;">
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o filled"></i>
                          <i class="fa fa-star-o"></i>
                          <!-- <p class="your-rating-text" id = "12" onclick="getCourseDetailsForRatingModal(this.id)">
                            <span class="your">Your</span>
                            <span class="edit">Edit</span>
                            Rating                                          
                          </p> -->
                       
                          <!-- <a href="javascript::" class="hidden" id="cancel_rating_btn_12" onclick="toggleRatingView('12')" style="color: #2a303b">Cancel rating</a> -->
                        </p>
                    </div>
                    <div class="row mb-2">
                      <div class="col-md-6">
                           <a href="#" class="btn btn-secondary myfont fs26"> বিস্তারিত </a>
                      </div>

                      <div class="col-md-6 text-right">
                        <a href="#" class="btn btn-outline-secondary myfont fs26">শিখা শুরু করুন </a>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
          
		</div>
	</div>
</div>
</div>

<!-- javascript code for filter dropdown select  -->
  <script>
    $('#dropdownMenuButton').on('show.bs.dropdown', function () {
      
    });          
  </script>


<?php include '../footer.php'; ?>

