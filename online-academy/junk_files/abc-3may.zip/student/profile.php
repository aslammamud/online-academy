<?php

  include ('student-header.php');

?>

<section class="user-dashboard-area">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="user-dashboard-box">
                    <div class="user-dashboard-sidebar">
                        <div class="user-box">
                            <img src="../images/alamin.jpg" alt="" class="img-fluid">
                            <div class="name">
                                <div class="name">Al-Amin Hossain</div>
                            </div>
                        </div>
                        <div class="user-dashboard-menu">
                            <ul>
                                <li class="active"><a href="../images/alamin.jpg">Profile</a></li>
                                <li><a href="account-settings.php">Account</a></li>
                                <li><a href="photo-settings.php">Photo</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="user-dashboard-content">
                        <div class="content-title-box">
                            <div class="title"><strong>Profile</strong></div>
                            <div class="subtitle">Add information about yourself to share on your profile.</div>
                        </div>
                        <form action="##" method="post">
                            <div class="content-box">
                                <div class="basic-group">
                                    <div class="form-group">
                                        <label for="FristName">Basics:</label>
                                        <input type="text" class="form-control" name="first_name" id="FristName" placeholder="First name" value="Signe">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="last_name" placeholder="Last name" value="Thompson">
                                    </div>
                                    <div class="form-group">
                                        <label for="Biography">Biography:</label>
                                        <textarea type="text" name="biography" id="mceu_2" cols="90" rows="6">Write Your Biography...</textarea>
                                        <!-- <div id="mceu_2" class="mce-tinymce mce-container mce-panel" hidefocus="1" tabindex="-1" role="application" style="visibility: hidden; border-width: 1px; width: 100%;"><div id="mceu_2-body" class="mce-container-body mce-stack-layout"><div id="mceu_3" class="mce-top-part mce-container mce-stack-layout-item mce-first"><div id="mceu_3-body" class="mce-container-body"><div id="mceu_4" class="mce-toolbar-grp mce-container mce-panel mce-first mce-last" hidefocus="1" tabindex="-1" role="group"><div id="mceu_4-body" class="mce-container-body mce-stack-layout"><div id="mceu_5" class="mce-container mce-toolbar mce-stack-layout-item mce-first mce-last" role="toolbar"><div id="mceu_5-body" class="mce-container-body mce-flow-layout"><div id="mceu_6" class="mce-container mce-flow-layout-item mce-first mce-last mce-btn-group" role="group"><div id="mceu_6-body"><div id="mceu_0" class="mce-widget mce-btn mce-first" tabindex="-1" aria-pressed="false" role="button" aria-label="Bold"><button id="mceu_0-button" role="presentation" type="button" tabindex="-1"><i class="mce-ico mce-i-bold"></i></button></div><div id="mceu_1" class="mce-widget mce-btn mce-last" tabindex="-1" aria-pressed="false" role="button" aria-label="Italic"><button id="mceu_1-button" role="presentation" type="button" tabindex="-1"><i class="mce-ico mce-i-italic"></i></button></div></div></div></div></div></div></div></div></div><div id="mceu_7" class="mce-edit-area mce-container mce-panel mce-stack-layout-item mce-last" hidefocus="1" tabindex="-1" role="group" style="border-width: 1px 0px 0px;"><iframe id="Biography_ifr" frameborder="0" allowtransparency="true" title="Rich Text Area. Press ALT-F9 for menu. Press ALT-F10 for toolbar. Press ALT-0 for help" style="width: 100%; height: 100px; display: block;"></iframe></div></div></div><textarea class="form-control author-biography-editor" name="biography" id="Biography" style="display: none;" aria-hidden="true">&lt;p&gt;hello world&lt;/p&gt;</textarea> -->
                                    </div>
                                </div>
                                <div class="link-group">
                                    <div class="form-group">
                                        <input type="text" class="form-control" maxlength="60" name="twitter_link" placeholder="Twitter link" value="https://www.twitter.com/john">
                                        <small class="form-text text-muted">Add your twitter link.</small>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" maxlength="60" name="facebook_link" placeholder="Facebook link" value="https://www.facebook.com/john">
                                        <small class="form-text text-muted">Add your facebook link.</small>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" maxlength="60" name="linkedin_link" placeholder="Linkedin link" value="https://www.linkedin.com/john">
                                        <small class="form-text text-muted">Add your linkedin link.</small>
                                    </div>
                                </div>
                            </div>
                            <div class="content-update-box">
                                <button type="submit" class="btn">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include '../footer.php'; ?>

