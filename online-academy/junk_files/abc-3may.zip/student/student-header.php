
<?php include ('../header.php'); ?>

<section id="student-panel" class="bred_cus">
<div class="col-md-12 col-sm-12 col-lg-12 ">
    <div class="student-panel-header">
      <p class="text-white myfont fs50">ড্যাশবোর্ড </p>
    </div>
    <div class="student-panel-menu mt-4 myfont fs26">
      <div class="d-flex flex-row">
        <div class="pl-2 pr-3 bd-highlight"> <a class="text-black" href="index.php">আমার ক্রয়কৃত কোর্স  </a> </div>
        <div class="pl-2 pr-3 bd-highlight"> <a class="text-white" href="wishlist.php"> পছন্দকৃত কোর্স </a> </div>
        <div class="pl-2 pr-3 bd-highlight"> <a class="text-white" href="message.php"> মেসেজ</a> </div>
        <div class="pl-2 pr-3 bd-highlight"> <a class="text-white" href="purchase-history.php"> পার্সেস হিস্টোরি </a> </div>
        <div class="pl-2 pr-3 bd-highlight"> <a class="text-white" href="profile.php"> প্রোফাইল</a> </div>
      </div>
    </div>
  </div>
</section>


