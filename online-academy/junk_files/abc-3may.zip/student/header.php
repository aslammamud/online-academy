<?php
require '../connection.inc.php';
require '../functions.inc.php';
?>

<!doctype html>
<html lang="en">
   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <meta http-equiv="content-type" content="text/html; charset=utf-8" />
      <meta name="author" content="AM" />
      <!-- Document Title -->
      <title>ABC Student Panel - নিজে শিখবো, অন্যকে শিখাবো </title>
	  <link rel="icon" href="images/icon.png" type="image/gif" sizes="16x16">	  
	  <link href="https://fonts.maateen.me/kalpurush/font.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
       <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" type="text/css" href="css/custom-style.css">
      <link rel="stylesheet" type="text/css" href="css/app.css">
      <link rel="stylesheet" type="text/css" href="css/custom.css">
	  
	  	  
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   </head>

   <body >
      <header class="header">
         <div class="header-fixed">
            <nav class="navbar navbar-expand-lg header-nav">
               <div class="navbar-header"><a id="mobile_btn" href=""><span class="bar-icon"><span></span><span></span><span></span></span></a><a href="../index.php" class="navbar-brand logo"><img src="images/ecourse-logo.png" class="img-fluid" alt="Logo"></a></div>
               <div class="main-menu-wrapper">
                  <div class="menu-header"><a href="../index.php" class="menu-logo"><img src="images/ecourse-logo.png" class="img-fluid" alt="Logo"></a><a id="menu_close" class="menu-close" href=""><i class="fas fa-times"></i></a></div>
                  <ul class="main-nav">
                     <li class="has-submenu myfont">
                        <a href=""><i class="fa fa-list" aria-hidden="true"></i> কোর্সসমূহ  <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                        <ul class="submenu">
                           <li class="myfont"><a href="courses.php">কোর্সসমূহ</a></li>
                        </ul>
                     </li>
					 <li class="live myfont"><a href="#"><i class="fa fa-circle" style="font-size:14px;color:#ff0000;" aria-hidden="true"></i>  লাইভ কোর্স&nbsp</a></li>
                  </ul>
               </div>

           <div class="search-cate nav navbar-right header-navbar-rht">
            <select class="selector">
             <option> All Categories</option>
             <option>Graphics Design</option>
             <option>Web Design</option>
			 <option>Web Development</option>
             <option>Data Entry</option>
             <option>Office Fundamental</option>
            </select>
        <input type="search" placeholder="Search here...">
        <button class="submit" type="submit"><i class="fa fa-search" style="color:#07b00b;" aria-hidden="true"></i></button>
      </div>
           <?php 
			if(isset($_SESSION['abc_lgn']) AND $_SESSION['abc_lgn'] == true){
						echo '
						<ul class="nav header-navbar-rht">
							<li class="nav-item"><a class="nav-link myfont" href=""><i class="fa fa-heart-o" aria-hidden="true"></i></a></li>
							<li class="nav-item"><a class="nav-link myfont" href=""><i class="fa fa-shopping-cart" aria-hidden="true"></i> </a></li>
							<div class="dropdown show">
							  <a class="nav-link h4 dropdown-toggle pt-3" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<img src="../images/alamin.jpg" alt="" height="20px" width="20px">&nbsp'.$abc_user_name.'</a>

							  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
								<a class="dropdown-item myfont fntsz" href="student">স্টুডেন্ট প্যানেল</a>
								<a class="dropdown-item myfont fntsz" href="logout.php"> লগ আউট &nbsp<i class="fa fa-sign-out" aria-hidden="true"></i></a>
							  </div>
							</div>
						</ul>
							';
					}else{
						//echo  reloader('../index.php',0);
					//	exit();
						// die();
					}
			   ?>  
            </nav>
         </div>
      </header>