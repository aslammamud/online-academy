
<?php include'header.php'; ?>

<div style="background-color: green; height: 10px;"></div>
<section id="title">
	<center><div><h3>কিভাবে পেমেন্ট করবেন ?</h3></div></center>
</section>
<style type="text/css">
	#title div{
		width: 100%;
		height: 80px;
		padding: 30px;
		background-color: #a4d68e;

	}
</style>



<section id="payment-method" style="margin-bottom: 100px;">
  <center><h3 style="margin-top: 40px;">আপনি যেকোনো একটি ম্যাথড বেছে নিন </h3></center>









<div id="content" > 


       <section class="padding-top-60 padding-bottom-60">
      <div class="container "> 
        <div class="row"> 
        <link rel="stylesheet" href="style.css">

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         Step 1
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <center><img src="./images/pay.jpg" width="90%" style="margin-bottom: 50px;"></center>
  <p  style="margin-bottom: 50px; margin-left: 30px;">Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button. Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button.</p>

      </div>
    </div>
  </div>
  
</div>

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         Step 2
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <p  style="margin-bottom: 50px;margin-left: 30px;">Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button. Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button.</p>
      </div>
    </div>
  </div>
  
</div>


<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700;background: transparent;">
         Step 3
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <p  style="margin-bottom: 50px;margin-left: 30px;">Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button. Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button.</p>
      </div>
    </div>
  </div>
  
</div>

<div id="accordion" style="width: 100%; border-radius: 10px; background-color: #6FD742;">

  <div class="card p-5">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn-link collapsed " data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" style="color: #6FD742;
    font-size: 32px;
    font-weight: 700; background: transparent;">
         Step 4
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body" >
       <h3 style="margin-left: 30px;"></h3>
  <p  style="margin-bottom: 50px;margin-left: 30px;">Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button. Fill your shopping cart by clicking “Add to Cart” or “Add to Bag” on each item you want to purchase. When you’re done, click the “Checkout” button.</p>
      </div>
    </div>
  </div>
  
</div>

</div>
</div>
</div>







  

 
</section>


<?php include'footer.php'; ?>